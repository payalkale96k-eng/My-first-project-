// CLOCK
function updateClock(){
  const n=new Date();
  document.getElementById('clock').textContent=n.toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false});
}
setInterval(updateClock,1000);updateClock();

// SPLASH LOADING TEXT
const msgs=["INITIALIZING SYSTEM...","LOADING PATIENT DATABASE...","CONNECTING TO LIVE FEEDS...","SYSTEM READY ✓"];
let mi=0;
const si=setInterval(()=>{
  mi++;
  if(mi<msgs.length) document.getElementById('splashStatus').textContent=msgs[mi];
  else clearInterval(si);
},700);

function enterDashboard(){
  document.getElementById('splash').classList.add('hidden');
}
// Auto-enter after 3.2s
setTimeout(enterDashboard,3200);

// TAB SWITCHING
function showTab(id,el){
  document.querySelectorAll('.section').forEach(s=>s.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  document.getElementById('sec-'+id).classList.add('active');
  el.classList.add('active');
}

// FLOOR TOGGLE
function toggleFloor(hdr){
  const rooms=hdr.nextElementSibling;
  const arrow=hdr.querySelector('span');
  if(rooms.style.display==='none'){rooms.style.display='grid';arrow.textContent='▼ EXPAND';}
  else{rooms.style.display='none';arrow.textContent='▶ COLLAPSED';}
}

// BED DATA — simulates live updates
const depts=[
  {name:'CARDIOLOGY',icon:'❤️',total:50,occ:42,res:4,maint:1},
  {name:'NEUROLOGY',icon:'🧠',total:45,occ:28,res:5,maint:2},
  {name:'ORTHOPEDIC',icon:'🦴',total:55,occ:30,res:8,maint:2},
  {name:'PEDIATRICS',icon:'👶',total:30,occ:14,res:6,maint:0},
  {name:'GENERAL',icon:'🏥',total:60,occ:35,res:10,maint:3},
  {name:'ICU',icon:'🫀',total:20,occ:17,res:2,maint:1},
];

function buildBeds(){
  let tA=0,tO=0,tR=0,tM=0;
  const bc=document.getElementById('bedCards');
  if(!bc)return;
  bc.innerHTML='';
  depts.forEach(d=>{
    const av=d.total-d.occ-d.res-d.maint;
    tA+=av;tO+=d.occ;tR+=d.res;tM+=d.maint;
    const pct=Math.round(d.occ/d.total*100);
    const [lbl,cls]=pct>=85?['CRITICAL','bcrit']:pct>=65?['WARNING','bwarn']:['AVAILABLE','bok'];
    const col=pct>=85?'var(--danger)':pct>=65?'var(--warn)':'var(--accent2)';
    const states=[...Array(d.occ).fill('boc'),...Array(av).fill('bav'),...Array(d.res).fill('bre'),...Array(d.maint).fill('bma')];
    for(let i=states.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[states[i],states[j]]=[states[j],states[i]];}
    const cells=states.slice(0,30).map((s,i)=>`<div class="bcell ${s}" title="Bed ${i+1}: ${s==='bav'?'Available':s==='boc'?'Occupied':s==='bre'?'Reserved':'Maintenance'}"></div>`).join('');
    bc.innerHTML+=`
    <div class="bed-card">
      <div class="bed-top">
        <div class="bed-dname">${d.icon} ${d.name}</div>
        <div class="badge ${cls}">${lbl}</div>
      </div>
      <div class="bedgrid">${cells}</div>
      <div class="bed-counts">
        <span class="bcount"><span class="bdot bav" style="display:inline-block;width:9px;height:9px;border-radius:2px"></span>${av} Avail</span>
        <span class="bcount"><span class="bdot boc" style="display:inline-block;width:9px;height:9px;border-radius:2px"></span>${d.occ} Occ</span>
        <span class="bcount"><span class="bdot bre" style="display:inline-block;width:9px;height:9px;border-radius:2px"></span>${d.res} Res</span>
        <span class="bcount"><span class="bdot bma" style="display:inline-block;width:9px;height:9px;border-radius:2px"></span>${d.maint} Maint</span>
      </div>
      <div class="occ-bar"><div class="occ-fill" style="width:${pct}%;background:${col}"></div></div>
      <div class="occ-pct"><span>Occupancy</span><span style="color:${col};font-weight:700">${pct}%</span></div>
    </div>`;
  });
  const bs=document.getElementById('bedSummary');
  if(bs) bs.innerHTML=`
    <div class="card cg"><div class="card-label">Available Beds</div><div class="card-val" style="color:var(--accent2)">${tA}</div><div class="card-sub">Ready for admission</div></div>
    <div class="card cr"><div class="card-label">Occupied Beds</div><div class="card-val" style="color:var(--danger)">${tO}</div><div class="card-sub">Currently in use</div></div>
    <div class="card cy"><div class="card-label">Reserved</div><div class="card-val" style="color:var(--warn)">${tR}</div><div class="card-sub">Pre-booked / On hold</div></div>
    <div class="card cp"><div class="card-label">Maintenance</div><div class="card-val" style="color:var(--purple)">${tM}</div><div class="card-sub">Under servicing</div></div>`;
}
buildBeds();

// Simulate live bed changes every 30s
setInterval(()=>{
  depts.forEach(d=>{
    d.occ=Math.max(0,Math.min(d.total-d.res-d.maint,d.occ+Math.floor(Math.random()*3)-1));
  });
  buildBeds();
},30000);

// DISEASE DATA
const diseases=[
  {dept:'Cardiology',icon:'🫀',name:'Coronary Artery Disease',cls:'dc',tx:'Angioplasty, CABG, statins, lifestyle changes',avail:true},
  {dept:'Cardiology',icon:'💓',name:'Heart Failure',cls:'dc',tx:'ACE inhibitors, beta-blockers, diuretics, device therapy',avail:true},
  {dept:'Cardiology',icon:'⚡',name:'Arrhythmia',cls:'dc',tx:'Ablation, cardioversion, antiarrhythmic drugs, pacemaker',avail:true},
  {dept:'Cardiology',icon:'🩸',name:'Hypertension',cls:'dc',tx:'Antihypertensives, ACE inhibitors, lifestyle modification',avail:true},
  {dept:'Cardiology',icon:'🫁',name:'Myocardial Infarction',cls:'dc',tx:'Primary PCI, thrombolysis, CABG, ICU monitoring',avail:false},
  {dept:'Cardiology',icon:'🔴',name:'Valvular Heart Disease',cls:'dc',tx:'Valve repair/replacement, balloon valvuloplasty',avail:true},
  {dept:'Cardiology',icon:'🩺',name:'Cardiomyopathy',cls:'dc',tx:'Medications, LVAD, cardiac transplant evaluation',avail:true},
  {dept:'Cardiology',icon:'💉',name:'Deep Vein Thrombosis',cls:'dc',tx:'Anticoagulation, thrombolysis, IVC filter',avail:true},
  {dept:'Cardiology',icon:'🔬',name:'Peripheral Artery Disease',cls:'dc',tx:'Angioplasty, bypass surgery, antiplatelet therapy',avail:true},
  {dept:'Cardiology',icon:'💊',name:'Atrial Fibrillation',cls:'dc',tx:'Rate control, rhythm control, anticoagulation, ablation',avail:true},
  {dept:'Cardiology',icon:'🫀',name:'Aortic Aneurysm',cls:'dc',tx:'EVAR, open surgery, surveillance',avail:true},
  {dept:'Cardiology',icon:'🩻',name:'Congenital Heart Defect',cls:'dc',tx:'Surgical correction, catheter-based closure',avail:true},
  {dept:'Neurology',icon:'🧠',name:'Ischemic Stroke',cls:'dn',tx:'tPA thrombolysis, thrombectomy, rehabilitation, aspirin',avail:true},
  {dept:'Neurology',icon:'💢',name:'Migraine',cls:'dn',tx:'Triptans, CGRP antagonists, preventive therapy, Botox',avail:true},
  {dept:'Neurology',icon:'⚡',name:'Epilepsy / Seizures',cls:'dn',tx:'AEDs, VNS, DBS, ketogenic diet, surgical resection',avail:true},
  {dept:'Neurology',icon:'🔄',name:"Parkinson's Disease",cls:'dn',tx:'Levodopa, DBS, physiotherapy, occupational therapy',avail:true},
  {dept:'Neurology',icon:'🤕',name:'Traumatic Brain Injury',cls:'dn',tx:'ICP monitoring, surgery, neuro-rehab, supportive care',avail:true},
  {dept:'Neurology',icon:'🦾',name:'Multiple Sclerosis',cls:'dn',tx:'DMTs, steroids, physiotherapy, symptom management',avail:true},
  {dept:'Neurology',icon:'😵',name:'Meningitis',cls:'dn',tx:'IV antibiotics/antivirals, steroids, ICU support',avail:true},
  {dept:'Neurology',icon:'🔴',name:'Brain Tumour',cls:'dn',tx:'Surgical resection, radiotherapy, chemotherapy',avail:false},
  {dept:'Neurology',icon:'🫀',name:'Spinal Cord Disorders',cls:'dn',tx:'Steroids, surgical decompression, rehabilitation',avail:true},
  {dept:'Neurology',icon:'😴',name:'Sleep Disorders',cls:'dn',tx:'CPAP, CBT-I, medications, sleep hygiene counselling',avail:true},
  {dept:'Orthopedic',icon:'🦴',name:'Fractures',cls:'do',tx:'Casting, ORIF, intramedullary nailing, external fixation',avail:true},
  {dept:'Orthopedic',icon:'🦵',name:'Knee Replacement',cls:'do',tx:'Total/partial knee arthroplasty, minimally invasive surgery',avail:true},
  {dept:'Orthopedic',icon:'💪',name:'Rotator Cuff Injury',cls:'do',tx:'Arthroscopy, physiotherapy, PRP injection, open repair',avail:true},
  {dept:'Orthopedic',icon:'🩻',name:'Spinal Disc Herniation',cls:'do',tx:'Microdiscectomy, physiotherapy, epidural steroids',avail:true},
  {dept:'Orthopedic',icon:'🦴',name:'Osteoporosis',cls:'do',tx:'Bisphosphonates, calcium/Vit D, fall prevention, DEXA',avail:true},
  {dept:'Orthopedic',icon:'🏃',name:'Sports Injuries',cls:'do',tx:'RICE, arthroscopy, ligament reconstruction, PRP therapy',avail:true},
  {dept:'Orthopedic',icon:'🦾',name:'Rheumatoid Arthritis',cls:'do',tx:'DMARDs, biologics, joint replacement, physiotherapy',avail:true},
  {dept:'Orthopedic',icon:'🦵',name:'Hip Replacement',cls:'do',tx:'Total hip arthroplasty, minimally invasive approach',avail:true},
  {dept:'Orthopedic',icon:'🩺',name:'Scoliosis',cls:'do',tx:'Bracing, physiotherapy, spinal fusion surgery',avail:true},
  {dept:'Orthopedic',icon:'💉',name:'Osteomyelitis',cls:'do',tx:'IV antibiotics, surgical debridement, bone grafting',avail:true},
  {dept:'Pediatrics',icon:'🤧',name:'Pneumonia',cls:'dp',tx:'Antibiotics, oxygen therapy, nebulisation, hydration',avail:true},
  {dept:'Pediatrics',icon:'🌡️',name:'Dengue Fever',cls:'dp',tx:'IV fluids, platelet monitoring, antipyretics, bed rest',avail:true},
  {dept:'Pediatrics',icon:'😮‍💨',name:'Asthma',cls:'dp',tx:'Bronchodilators, inhaled steroids, spacer, nebuliser',avail:true},
  {dept:'Pediatrics',icon:'👶',name:'Neonatal Jaundice',cls:'dp',tx:'Phototherapy, exchange transfusion, hydration',avail:true},
  {dept:'Pediatrics',icon:'🤒',name:'Typhoid',cls:'dp',tx:'Ciprofloxacin/ceftriaxone, hydration, nutrition support',avail:true},
  {dept:'Pediatrics',icon:'💉',name:'Malnutrition',cls:'dp',tx:'RUTF, therapeutic feeding, micronutrient supplementation',avail:true},
  {dept:'Pediatrics',icon:'🧠',name:'Febrile Seizures',cls:'dp',tx:'Antipyretics, benzodiazepines, parent counselling',avail:true},
  {dept:'Pediatrics',icon:'🩸',name:'Anaemia',cls:'dp',tx:'Iron supplements, folic acid, dietary advice, transfusion',avail:true},
  {dept:'Pediatrics',icon:'🤧',name:'Acute Gastroenteritis',cls:'dp',tx:'ORS, IV fluids, probiotics, zinc supplementation',avail:true},
  {dept:'Pediatrics',icon:'🔴',name:'Congenital Disorders',cls:'dp',tx:'Multidisciplinary management, surgery, genetic counselling',avail:false},
  {dept:'General',icon:'🤧',name:'Respiratory Infections',cls:'dg',tx:'Antibiotics, antivirals, supportive care, nebulisation',avail:true},
  {dept:'General',icon:'🩸',name:'Diabetes Mellitus',cls:'dg',tx:'Insulin, oral hypoglycaemics, diet modification, monitoring',avail:true},
  {dept:'General',icon:'🦠',name:'Malaria',cls:'dg',tx:'Chloroquine, artemisinin, supportive care, blood transfusion',avail:true},
  {dept:'General',icon:'🤒',name:'Viral Fever',cls:'dg',tx:'Antipyretics, hydration, rest, symptomatic treatment',avail:true},
  {dept:'General',icon:'💊',name:'Thyroid Disorders',cls:'dg',tx:'Levothyroxine, antithyroid drugs, radioiodine, surgery',avail:true},
  {dept:'General',icon:'🩺',name:'UTI',cls:'dg',tx:'Antibiotics, hydration, urine culture-guided therapy',avail:true},
  {dept:'General',icon:'🔬',name:'HIV/AIDS',cls:'dg',tx:'ART, opportunistic infection prophylaxis, counselling',avail:true},
  {dept:'General',icon:'💉',name:'Vitamin Deficiencies',cls:'dg',tx:'Supplementation (B12, D, folate), dietary modification',avail:true},
  {dept:'General',icon:'🧪',name:'Liver Disease',cls:'dg',tx:'Antivirals, diuretics, lactulose, transplant evaluation',avail:true},
  {dept:'General',icon:'🤕',name:'General Injuries',cls:'dg',tx:'Wound care, suturing, tetanus prophylaxis, dressing',avail:true},
];

let deptFilter='';
function renderDis(q){
  const grid=document.getElementById('disGrid');
  if(!grid)return;
  grid.innerHTML='';
  const ql=(q||'').toLowerCase();
  diseases.filter(d=>(!deptFilter||d.dept===deptFilter)&&(!ql||d.name.toLowerCase().includes(ql)||d.dept.toLowerCase().includes(ql)||d.tx.toLowerCase().includes(ql)))
  .forEach(d=>{
    grid.innerHTML+=`
    <div class="dis-card">
      <div class="dis-icon">${d.icon}</div>
      <div class="dis-name">${d.name}</div>
      <div class="dep-tag ${d.cls}">${d.dept}</div>
      <div class="dis-tx">📋 ${d.tx}</div>
      <div class="dis-avail ${d.avail?'avail-y':'avail-n'}">${d.avail?'✅ Treatment Available':'⚠️ Limited — Contact Admin'}</div>
    </div>`;
  });
  if(!grid.innerHTML) grid.innerHTML='<div style="color:var(--muted);padding:20px;font-size:13px;grid-column:1/-1">No results found.</div>';
}
function filterDis(v){renderDis(v);}
function filterByDept(d){deptFilter=d;renderDis('');}
renderDis('');
