# SmartCare Hospital Analytics System

## Project File Structure
```
SmartCare_VS_Project/
├── index.html    ← HTML structure (all tabs, cards, layout)
├── style.css     ← CSS styling (animations, colors, dark theme)
├── script.js     ← JavaScript (live clock, bed updates, search, charts)
└── README.md     ← This file
```

## How to Run in VS Code

### Method 1 — Live Server (Recommended)
1. Open VS Code
2. Install extension: **Live Server** (by Ritwick Dey)
3. Right-click `index.html` → **"Open with Live Server"**
4. Browser opens at localhost:5500 ✅

### Method 2 — Direct Browser
1. Double-click `index.html`
2. Opens in Chrome/Edge instantly ✅

## Technologies Used
| File        | Technology | Purpose                        |
|-------------|------------|-------------------------------|
| index.html  | HTML5      | Page structure & content       |
| style.css   | CSS3       | Animations, layout, dark theme |
| script.js   | JavaScript | Live data, interactivity, logic|

## Features
- Animated Splash/Intro Screen
- Real-Time Clock
- Bed Availability (auto-updates every 30s)
- Emergency Triage System
- 52 Diseases & Treatments (searchable)
- Hospital Infrastructure (floor-by-floor)
- Analytics & Charts from 20,000 patient records

## Dataset Info
- 20,000 patient records (2021–2024)
- 5 Departments: Cardiology, Neurology, Orthopedic, Pediatrics, General
- Total Revenue: ₹128 Crore
